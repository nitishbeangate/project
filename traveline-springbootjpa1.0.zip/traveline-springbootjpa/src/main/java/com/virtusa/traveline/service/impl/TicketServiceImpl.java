package com.virtusa.traveline.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.virtusa.traveline.model.PassengerContact;
import com.virtusa.traveline.model.PassengerDetail;
import com.virtusa.traveline.repository.TicketRepository;
import com.virtusa.traveline.service.TicketService;

@Service
public class TicketServiceImpl implements TicketService  {
     
	@Autowired
	private TicketRepository ticketrepo;
	@Override
	public String ticketGeneration(PassengerContact passengercontact,List<PassengerDetail> passengerdetail) {
		// TODO Auto-generated method stub
		ticketrepo.save(passengercontact);
		//ticketrepo.saveAll(passengerdetail);
		return "added";
	}

}
