package com.virtusa.traveline.service;

import java.util.List;

import com.virtusa.traveline.model.PassengerContact;
import com.virtusa.traveline.model.PassengerDetail;

public interface TicketService {

	public String ticketGeneration(PassengerContact passengercontact,List<PassengerDetail> passengerdetail);

	
}
