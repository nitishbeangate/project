package com.virtusa.traveline.exception;

public class RunTimeException extends RuntimeException {

	public Admin
}
