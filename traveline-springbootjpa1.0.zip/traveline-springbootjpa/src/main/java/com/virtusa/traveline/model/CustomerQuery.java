/*
 * package com.virtusa.traveline.model; import java.sql.Date; import
 * javax.persistence.Entity; import javax.persistence.GeneratedValue; import
 * javax.persistence.GenerationType; import
 * org.springframework.data.annotation.CreatedDate;
 * 
 * @Entity public class CustomerQuery { private String email; private String
 * querymessage;
 * 
 * @GeneratedValue(strategy = GenerationType.AUTO) private int id;
 * 
 * @CreatedDate private Date date;
 * 
 * public Date getDate() { return date; }
 * 
 * public int getId() { return id; }
 * 
 * public String getEmail() { return email; }
 * 
 * public void setEmail(String email) { this.email = email; }
 * 
 * public String getQuerymessage() { return querymessage; }
 * 
 * public void setQuerymessage(String querymessage) { this.querymessage =
 * querymessage; }
 * 
 * 
 * 
 * }
 */