package com.virtusa.selenium;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

/*Case Study 1:
1. Goto  ebay.in
2. Click on register link
3. Fill the required fields(Use different locators for different elements)
4. Click on register
*/
public class TestCase01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriverManager .chromedriver().setup(); //loading chrome driver from binary file
		
		WebDriver driver=new ChromeDriver(); //creating a driver of type web
		caseStudy10(driver);
	
        //driver.close();
       
   
	}
	
	
	
	/*Case Study 1:
1. Goto  ebay.in
2. Click on register link
3. Fill the required fields(Use different locators for different elements)
4. Click on register
*/
	public static void caseStudy1(WebDriver driver)
	{
		String baseurl="https://ebay.in"; //string url
        driver.get(baseurl); //opening base url in browser
		
        driver.findElement(By.linkText("register")).click(); //clicking on register link
        driver.findElement(By.name("firstname")).sendKeys("nitish"); // finding element by name
        driver.findElement(By.id("lastname")).sendKeys("kumar");   //finding element by id
        driver.findElement(By.name("email")).sendKeys("nitish@gmail.com");
        driver.findElement(By.name("PASSWORD")).sendKeys("Nitish@123");
        driver.findElement(By.linkText("Create account")).click(); //clicking on create account button
      	
		
	}
	
/*
 * case study 10:
Goto Google search engine
Search for any term/word
Capture the data in autosuggest window and print it.	
 */
	
public static void caseStudy10(WebDriver driver)
{
driver.get("https://www.google.com");	
driver.findElement(By.xpath("//input[@type='text']").name("q")).sendKeys("virtusa");
List<WebElement> lstGoogle = driver.findElement(By.xpath("//ul[@role='listbox']"))
.findElements(By.xpath("//li[@role='presentation']"));
for (int i = 0; i < lstGoogle.size(); i++) {
	System.out.println(lstGoogle.get(i).getText());
}

//System.out.println("total textboxes "+suggestion.size());
	
}
	
/*Case Study : 14
1. Goto http://www.destinationqa.com/aut/sample.html
2. Get total no. of Text boxes avaialable.
3. Get & Print the default text on the address text box
 */
	public static void caseStudy14(WebDriver driver)
	{
		driver.get(" http://www.destinationqa.com/aut/sample.html");
		List <WebElement>  totalTextboxes=driver.findElements(By.xpath("//input[@type='text']"));
		System.out.println("total textboxes "+totalTextboxes.size());
		
		/*there is no address text box available*/
		//System.out.println("default text on the address text box"+totalTextboxes);
	}
	
}
