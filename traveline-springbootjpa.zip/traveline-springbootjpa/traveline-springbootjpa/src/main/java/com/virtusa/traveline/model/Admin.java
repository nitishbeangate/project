package com.virtusa.traveline.model;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.validator.constraints.Length;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import javax.persistence.*;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;

import java.util.Date;
import java.util.Set;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity
@EntityListeners(AuditingEntityListener.class)
@JsonIgnoreProperties(
		value={"created_at","updated_at"},
		allowGetters=true
		)
public class Admin {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	@Column(nullable=false)
	private String adusername;
	@Column(unique=true,nullable=false)
	private String ademail;
	@Column(nullable=false)
	private String adpassword;
	@Column(insertable=true)
	private Boolean status;
	@CreatedDate
	private Date created_at;
	@Temporal(TemporalType.TIMESTAMP)
	@LastModifiedDate
	private Date updated_at;
	
	public  String getAdusername() {
		return adusername;
	}
	public Admin setAdusername(String adusername) {
		this.adusername = adusername;
		return this;
	}
	public String getAdemail() {
		return ademail;
	}
	public Admin setAdemail(String ademail) {
		this.ademail = ademail;
		return this;
	}
	public String getAdpassword() {
		return adpassword;
	}
	public  Admin setAdpassword(String adpassword) {
		this.adpassword = adpassword;
		return this;
	}
	public int getId() {
		return id;
	}
	public Date getCreated_at() {
		return created_at;
	}
	public void setCreated_at(Date created_at) {
		this.created_at = created_at;
	}
	public Date getUpdated_at() {
		return updated_at;
	}
	public void setUpdated_at(Date updated_at) {
		this.updated_at = updated_at;
	}
	public Boolean getStatus() {
		return status;
	}
	public Admin setStatus(Boolean status) {
		this.status = status;
		return this;
	}
	
}