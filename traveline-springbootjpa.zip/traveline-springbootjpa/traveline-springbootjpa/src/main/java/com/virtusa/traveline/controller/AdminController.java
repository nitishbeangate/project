package com.virtusa.traveline.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class AdminController {
	@RequestMapping("/admin_home")
	
	public String adminHome(Model model)
	{
		
		return "admin/admin_home";
	}
	@GetMapping("/add_bus")
	public String addBus()
	{
	 return "admin/add_buses";
		
	}
	@GetMapping("/newAdmin")
	public String addAdmin()
	{
	 return "admin/add_admin";
		
	}
}
