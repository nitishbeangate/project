package com.virtusa.traveline.service;
import java.util.List;
import org.springframework.stereotype.Service;
import com.virtusa.traveline.model.Admin;

//service interface only have declaration
@Service
public interface AdminService {

//function that return list of admin 
public List<Admin> getAllAdmin();

//function to create a new admin
public int createAdmin(Admin admin);

//function to update admin details
public Boolean updateAdmin();

public int createAdmin(); 
}
