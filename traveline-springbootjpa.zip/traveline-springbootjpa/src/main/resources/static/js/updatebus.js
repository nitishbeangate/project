$(document).ready(function(){
$("#success").click(function(){
       $.ajax({
            method:'POST',
            url:'db_file/update_bus_db.jsp',
            data:$('#updatebus').serialize(),
            success:function(data)
            {
                alert(data);
                
            },
            error:function()
            {
                $("#aderror").show().html(data).hide(10000);
            },
            
            });
            });
});        



