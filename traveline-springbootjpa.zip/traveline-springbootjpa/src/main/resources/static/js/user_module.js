$(document).ready(function(){
    $("#bookinghistory1").show();
    $("#bookinghistory").addClass("activetab");
    $(".list-group a").click(function(){
      $("#bookinghistory1").fadeOut();
     $("#tab_div .panel-default").hide();
      $(".list-group a").removeClass("activetab");
      $(this).addClass("activetab");
      var a=$(this).attr("id");
      $('#'+a+'1').fadeIn();
    });
    $("#addfeedback").click(function(){
    $.ajax({
    method:'POST',
    url:'feedback.jsp',
    data:$("#feedbackform").serialize(),
    success:function(data)
    {
    $("#message").html(data);
    $("#message").hide(7000);
    $("#feedbackform")[0].reset();
    }
    });
    
    });
    
    //queryform ajax
    $("#addquery").click(function(){
    	if($("#qemail").val()=="" || $("#query").text()=="")
    		{
    		$("#queryvalidation").show().hide(10000);
    		}
    	else
    		{
        $.ajax({
        method:'POST',
        url:'db_file/queryform.jsp',
        data:$("#queryform").serialize(),
        success:function(data)
        {
        $("#message").html(data);
        $("#message").hide(7000);
        }
        });
    		}
        });
    
});