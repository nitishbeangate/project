/*
 * package com.virtusa.traveline.projection;
 * 
 * public class AdminProjection {
 * 
 * public interface AdminData { public int getId(); }
 * 
 * }
 */