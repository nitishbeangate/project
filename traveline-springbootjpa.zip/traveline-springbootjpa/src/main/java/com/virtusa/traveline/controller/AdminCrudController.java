package com.virtusa.traveline.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.virtusa.traveline.model.Admin;
import com.virtusa.traveline.service.AdminService;

@RestController
public class AdminCrudController {
    @Autowired
	private AdminService adservice;
	
	/*
	 * @PostMapping("/addAdmin") public ResponseEntity<Optional>
	 * addAdmin(@RequestBody Admin admin) { adservice.createAdmin(admin); return new
	 * ResponseEntity<Optional>(HttpStatus.OK); }
	 */
	// function returning list of admin
	@PostMapping("/getallAdmin")
	  public List<Admin> getAdminData() { 
		  return adservice.getAllAdmin();
	  
	  }
	 
	 

}
