package com.virtusa.traveline.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.virtusa.traveline.model.Admin;

public interface AdminRepository extends JpaRepository<Admin, Integer> {

}
