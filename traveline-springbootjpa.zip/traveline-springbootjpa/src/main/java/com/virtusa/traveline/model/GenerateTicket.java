package com.virtusa.traveline.model;

import java.util.List;

public class GenerateTicket {
private String MPname;
private String MPemail;
private String MPcontact;
private List<PassengerDetail> passenger;
public String getMPname() {
	return MPname;
}
public void setMPname(String mPname) {
	MPname = mPname;
}
public String getMPemail() {
	return MPemail;
}
public void setMPemail(String mPemail) {
	MPemail = mPemail;
}
public String getMPcontact() {
	return MPcontact;
}
public void setMPcontact(String mPcontact) {
	MPcontact = mPcontact;
}
public List<PassengerDetail> getPassenger() {
	return passenger;
}
public void setPassenger(List<PassengerDetail> passenger) {
	this.passenger = passenger;
}



}
