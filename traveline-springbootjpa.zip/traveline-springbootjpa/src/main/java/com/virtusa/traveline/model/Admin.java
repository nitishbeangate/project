package com.virtusa.traveline.model;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.*;

@Entity
@EntityListeners(AuditingEntityListener.class)
@JsonIgnoreProperties(
		value={"created_at","updated_at"},
		allowGetters=true
		)
public class Admin implements Serializable{
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	@Column(nullable=false)
	private String adusername;
	@Column(unique=true,nullable=false)
	private String ademail;
	@Column(nullable=false)
	@JsonIgnore
	private String adpassword;
	@Column(insertable=true)
	private Boolean status=true;
	@CreatedDate
	private Date created_at;
	@Temporal(TemporalType.TIMESTAMP)
	@LastModifiedDate
	private Date updated_at;
	public int getId() {
		return id;
	}
	public String getAdusername() {
		return adusername;
	}
	public void setAdusername(String adusername) {
		this.adusername = adusername;
	}
	public String getAdemail() {
		return ademail;
	}
	public void setAdemail(String ademail) {
		this.ademail = ademail;
	}
	public String getAdpassword() {
		return adpassword;
	}
	public void setAdpassword(String adpassword) {
		this.adpassword = adpassword;
	}
	public Boolean getStatus() {
		return status;
	}
	public void setStatus(Boolean status) {
		this.status = status;
	}
	public Date getCreated_at() {
		return created_at;
	}
	
	public Date getUpdated_at() {
		return updated_at;
	}
	

	
}