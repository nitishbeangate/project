package com.virtusa.traveline.service.impl;

import java.util.List;

import javax.annotation.PostConstruct;

import com.virtusa.traveline.model.Admin;
import com.virtusa.traveline.repository.AdminRepository;
import com.virtusa.traveline.service.AdminService;

public abstract class AdminServiceImpl implements AdminService {

	private AdminRepository adminrepo;

	@Override
	// function implemention that return list of admin
	public List<Admin> getAllAdmin() {
		return adminrepo.findAll();
	}

	@Override
	// function implementation that save admin data
	@PostConstruct
	public int createAdmin() {
		Admin admin1 = new Admin();
		admin1.setAdemail("nitish@gmail.com").setAdusername("nitish").setStatus(true);
		adminrepo.save(admin1);
		if (adminrepo.count() > 0) {
			return 1;
		} else {
			return 0;
		}
	}

	@Override
	// function implementation to update admin data
	public Boolean updateAdmin() {

		return null;
	}

}
