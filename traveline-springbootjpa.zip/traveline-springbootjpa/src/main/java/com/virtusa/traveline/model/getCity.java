package com.virtusa.traveline.model;

public class getCity {
private String city;

public String getCity() {
	return city;
}

public void setCity(String city) {
	this.city = city;
}

}
