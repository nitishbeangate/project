//jquery start
$(document).ready(function(){
	
	//function calling
	generatesit();
	var bookedsit=[1,5,7,9,12];
	//function to generate seat
	function generatesit()
	{
		//looping
		for (var i=1;i<=50;i++) {
			var a="<button type='button'data-seat='"+i+"' class='btn seat'>"+i+"</button> ";
			var b="<button type='button' class='btn btn-danger'>"+i+"</button> ";
        //condition
			if (i<=25) {

				$(".seatdesign").append(a);
				continue;
			}
			$(".seatdesign1").append(a);
		}
	}
	//on seat click receiving seat no and adding class 
	$(".seat").click(function(){
		var seatno=$(this).data('seat');
		$("#psgdetail").removeClass("hidden");
		if ($(this).hasClass("btn-success")) {
			$('button[data-seat = '+seatno+']').removeClass("btn-success");
			$("#s"+seatno).remove();	
		}
		else
		{
			$('button[data-seat = '+seatno+']').toggleClass('btn-success');
			appendpassenger(seatno);
		}

	});
	//function to generate passenger details
	function appendpassenger(seat)
	{
		//concatenation
		var appendrow="";
		appendrow+="<div class='panel panel-default' id='s"+seat+"'><div class='panel-body'>";
		appendrow+="<div class='col-md-2 col-xs-12'>";
		appendrow+="<input type='text' class='form from-control seat_no' name='seat_no' value='"+seat+"' readonly></div>";
		appendrow+="<div class='col-md-4 col-xs-12'>";
		appendrow+="<input type='text' name='pname' placeholder='Enter Name' class='form form-control pname'></div>";
		appendrow+="<div class='col-md-3 col-xs-12'>";
		appendrow+="<input type='number' name='p_age' placeholder='Enter age' class='form form-control p_age'></div>";
		appendrow+="<div class='col-md-3'>";
		appendrow+="<select class='form form-control pgender' name='pgender'>";
		appendrow+="<option value=''>Select</option><option value='male'>Male</option><option value='female'>Female</option>";
		appendrow+="</select>";
		appendrow+="</div></div></div>";
		//appending form
		$("#appendpassenger").append(appendrow);
	}
	//goto payment
	$("#nexttopayment").click(function(){
		//checking null validation
		if($("#Pcname").val()=="" || $("#pemail").val()=="" || $("#Pcontact").val()=="")
			{
			$("#pcontacterror").show().hide(6000);
			return;
			}
		//email validation
		else if(!validateEmail($("#pemail").val()))
	    {
		$("#pcontacterror").show().html("please enter valid email").hide(10000);
	    }
		//phone validation
	else if(($("#Pcontact").val()).length<10)
	    {
		$("#pcontacterror").show().html("Mobile Number must be 10 digit").hide(10000);
	    }
		//all validation done then
		else
			{
		$("#passengerDetail").hide();
		$("#paymentDiv").show();
		$("#paymentpage").html("Payment");
			}
	});
	//goback to passenger
	$("#backtopasseger").click(function(){
		$("#passengerDetail").show();
		$("#paymentDiv").hide();
		$("#paymentpage").html("Available Seat");
	});
	//email validation function
	//email validation
	function validateEmail($email) {

	      var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;

	 

	      return emailReg.test( $email );

	 

	    }
	
	
	
	//click function 
	$("#paymentDone").click(function(){
        //array declaration
		var seat_no=[];
		var pname=[];
		var pgender=[];
		var p_age=[];
       //for each loop
		$('.seat_no').each(function(){
			seat_no.push($(this).val());

		});

		$('.pname').each(function(){
			pname.push($(this).val());
		});

		$('.pgender option:selected').each(function(){
			pgender.push($(this).text());
		});
		//fetching all age using class and pushing into array
		$('.p_age').each(function(){
			p_age.push($(this).val());
		});
		  jsonObj = [];
		  	  
	   passengercontact={
		        "p_name": $("#Pcname").val(),
		        "p_email":$("#pemail").val(),
		        "contact": $("#Pcontact").val(),
		        passengerdetail:[],
		        payment:$('#paymentDetail').serializeJSON(),
		        passengeridentity:$('#identity').serializeJSON()
	          };
	   
	   //var passenger={"passengerdetail":[]};

		  $('.seat_no').each(function(i)
		  {
		    passengercontact.passengerdetail.push({
		      "seatNO":parseInt(seat_no[i]), 
		      "pname":pname[i], 
		      "age":parseInt(p_age[i]),
		      "gender":pgender[i]
		    });
		  });
		  
		  console.log(passengercontact);
		$.ajax({
			method:'POST',
			contentType : "application/json",
			dataType:'json',
			url:'/generate/ticket',
			data:JSON.stringify(passengercontact), //converting form to single object
			success:function(data)
			{
				alert(data);	 
			},
			error:function(data)
			{
				alert(data);	 
			},
		});
	});
});