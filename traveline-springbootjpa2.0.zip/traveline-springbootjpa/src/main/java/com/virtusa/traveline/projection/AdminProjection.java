package com.virtusa.traveline.projection;
  
  public interface AdminProjection {
 
	public int getId(); 
	public String getAdemail();
	public Boolean getStatus();
	public String getAdusername();
  }
 