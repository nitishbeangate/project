package com.virtusa.traveline.projection;

import org.springframework.data.jpa.repository.JpaRepository;

import com.virtusa.traveline.model.AddBus;

public interface BusRepository extends JpaRepository<AddBus, Integer> {

}
