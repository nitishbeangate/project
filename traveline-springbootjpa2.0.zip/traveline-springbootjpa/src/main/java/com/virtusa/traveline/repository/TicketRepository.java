package com.virtusa.traveline.repository;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.virtusa.traveline.model.PassengerContact;
import com.virtusa.traveline.model.PassengerDetail;

@Repository
public interface TicketRepository extends JpaRepository<PassengerContact,Integer> {

	void save(List<PassengerDetail> passengerdetail);
	
	//function to fetch ticket detail
	
	public PassengerContact findById(int id);

}
