package com.virtusa.traveline.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.virtusa.traveline.model.Admin;
import com.virtusa.traveline.projection.AdminProjection;

@Repository

public interface AdminRepository extends JpaRepository<Admin, Integer> {

	
	  //jpa function to fetch specific data public interface AdminData 
	public List<AdminProjection> findBy();
	
}
