package com.virtusa.traveline.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.virtusa.traveline.model.Admin;
import com.virtusa.traveline.model.PassengerContact;
import com.virtusa.traveline.model.PassengerDetail;
import com.virtusa.traveline.repository.TicketRepository;
import com.virtusa.traveline.service.TicketService;

@RestController
@RequestMapping("/generate")
public class TicketController {
	@Autowired
	TicketService ticketservice;
	@Autowired
	TicketRepository ts;

	@PostMapping(value="/ticket",consumes = MediaType.APPLICATION_JSON_VALUE,   produces = { MediaType.APPLICATION_JSON_VALUE })
	public @ResponseBody String generateTicket(@RequestBody PassengerContact passengercontact) {
		
		
		return ticketservice.ticketGeneration(passengercontact);
	}
	@PostMapping("/getticket")
	public @ResponseBody List<PassengerContact> getTicket()
	{
		return ts.findAll();
	}
	//function to fetch ticket detail
	@PostMapping("/searchByPnr")
	public  String getDetail(@RequestParam int pid,Model model)
	{
		model.addAttribute("passengerData",ticketservice.passengerDetail(1));
		//model.setViewName("user_module");
		System.out.println(pid);
		System.out.println("data"+ticketservice.passengerDetail(1).toString());
		return "user_module";			
	}

}
