package com.virtusa.traveline.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.virtusa.traveline.model.AddBus;
import com.virtusa.traveline.projection.BusRepository;

@Controller
@RequestMapping("/bus")
public class BusController {

	@Autowired
	private BusRepository busrepo;
	@PostMapping("/addbus")
	public String addBus(@ModelAttribute AddBus addbus)
	{
		busrepo.save(addbus);
		return "done";
	}

}
