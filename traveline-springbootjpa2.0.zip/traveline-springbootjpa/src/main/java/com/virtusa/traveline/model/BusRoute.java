package com.virtusa.traveline.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class BusRoute implements Serializable {

/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
@Id	
@GeneratedValue
private int routeId;
private String locFrom;
private String locTo;
private int distance;
private int fare;
public int getRouteId() {
	return routeId;
}
public void setRouteId(int routeId) {
	this.routeId = routeId;
}
public String getLocFrom() {
	return locFrom;
}
public void setLocFrom(String locFrom) {
	this.locFrom = locFrom;
}
public String getLocTo() {
	return locTo;
}
public void setLocTo(String locTo) {
	this.locTo = locTo;
}
public int getDistance() {
	return distance;
}
public void setDistance(int distance) {
	this.distance = distance;
}
public int getFare() {
	return fare;
}
public void setFare(int fare) {
	this.fare = fare;
}


}
