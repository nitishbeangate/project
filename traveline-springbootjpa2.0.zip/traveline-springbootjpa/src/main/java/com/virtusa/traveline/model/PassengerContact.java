package com.virtusa.traveline.model;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity
public class PassengerContact implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	@Column(nullable = false)
	private String p_name;
	@Column(nullable = false)
	private String p_email;
	@Column(nullable = false, length = 10)
	private String contact;

	// list of passenger from passenger detail class
	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "fk_pcid", referencedColumnName = "id", nullable = false)
	private List<PassengerDetail> passengerdetail;

	/* creating relationship between passenger and payment Onetoone relationship  */
	@OneToOne(cascade = CascadeType.ALL)
	private Payment payment;
	
	/*creating relationship between passenger and passenger identity*/
	@OneToOne(cascade = CascadeType.ALL)
	private PassengerIdentity passengeridentity;
	
	
	
	public PassengerIdentity getPassengeridentity() {
		return passengeridentity;
	}

	public void setPassengeridentity(PassengerIdentity passengeridentity) {
		this.passengeridentity = passengeridentity;
	}

	public List<PassengerDetail> getPassengerdetail() {
		return passengerdetail;
	}

	public void setPassengerdetail(List<PassengerDetail> passengerdetail) {
		this.passengerdetail = passengerdetail;
	}

	public Payment getPayment() {
		return payment;
	}

	public void setPayment(Payment payment) {
		this.payment = payment;
	}

	

	public int getId() {
		return id;
	}

	public String getP_name() {
		return p_name;
	}

	public void setP_name(String p_name) {
		this.p_name = p_name;
	}

	public String getP_email() {
		return p_email;
	}

	public void setP_email(String p_email) {
		this.p_email = p_email;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

}
