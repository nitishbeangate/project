package com.virtusa.traveline.exception;

public class TicketNotFound extends RuntimeException {

}
