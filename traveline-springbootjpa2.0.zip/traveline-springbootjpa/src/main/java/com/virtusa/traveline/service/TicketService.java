package com.virtusa.traveline.service;

import com.virtusa.traveline.model.PassengerContact;

public interface TicketService {

	public String ticketGeneration(PassengerContact passengercontact);
	
	//function declaration to find detail by pnr no
	
	public PassengerContact passengerDetail(int id);
	

	
}
