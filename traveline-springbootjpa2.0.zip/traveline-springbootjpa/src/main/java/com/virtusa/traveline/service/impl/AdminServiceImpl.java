package com.virtusa.traveline.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.virtusa.traveline.model.Admin;
import com.virtusa.traveline.repository.AdminRepository;
//import com.virtusa.traveline.repository.AdminRepository.AdminData;
import com.virtusa.traveline.service.AdminService;

@Service
@Transactional
public class AdminServiceImpl implements AdminService {

	@Autowired
	private  AdminRepository adminrepo;
		
	//service method implementation
	@Override
	@Transactional
	public String createAdmin(Admin admin) {
        
		adminrepo.save(admin);
		return "added";
	}
	
	//return all admin
	
	@Override 
	public List<Admin> getAllAdmin() 
	{ // TODO Auto-generated
	  return adminrepo.findAll();
	  }
	 

}
