package com.virtusa.traveline.model;

import java.util.Date;



public class Pnr {
private String locFrom;
private String locTo;
private Date journeyDate;
private String pnrNo;
private int totalSeats;
private int msg_pid;



public int getMsg_pid() {
	return msg_pid;
}
public void setMsg_pid(int msg_pid) {
	this.msg_pid = msg_pid;
}
public String getLocFrom() {
    return locFrom;
}
public void setLocFrom(String locFrom) {
    this.locFrom = locFrom;
}
public String getLocTo() {
    return locTo;
}
public void setLocTo(String locTo) {
    this.locTo = locTo;
}
public Date getJourneyDate() {
    return journeyDate;
}
public void setJourneyDate(Date journeyDate) {
    this.journeyDate = journeyDate;
}
public String getPnrNo() {
    return pnrNo;
}
public void setPnrNo(String pnrNo) {
    this.pnrNo = pnrNo;
}
public int getTotalSeats() {
    return totalSeats;
}
public void setTotalSeats(int totalSeats) {
    this.totalSeats = totalSeats;
}



}