package com.virtusa.traveline.model;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import org.hibernate.annotations.CreationTimestamp;
@Entity
@Table(name = "bus_detail")
public class AddBus {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
private int id;
@Column(unique = true,nullable = false)
private String busNo;
@Column(nullable = false)
private String busName;
@Column(nullable = false)
private String busType;
@Column(nullable = false)
private int totalSeats;

@CreationTimestamp
private Date created_at;
private boolean status=true;


public String getBusNo() {
	return busNo;
}
public void setBusNo(String busNo) {
	this.busNo = busNo;
}
public String getBusName() {
	return busName;
}
public void setBusName(String busName) {
	this.busName = busName;
}
public String getBusType() {
	return busType;
}
public void setBusType(String busType) {
	this.busType = busType;
}
public int getTotalSeats() {
	return totalSeats;
}
public void setTotalSeats(int totalSeats) {
	this.totalSeats = totalSeats;
}
public boolean isStatus() {
	return status;
}
public void setStatus(boolean status) {
	this.status = status;
}

}
