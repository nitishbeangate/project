package com.virtusa.traveline.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.virtusa.traveline.model.Admin;
import com.virtusa.traveline.service.AdminService;

@RestController
@RequestMapping("/admin")
public class AdminCrudController {
	@Autowired
	private AdminService adservice;

	
	@PostMapping(value="/addAdmin",consumes = MediaType.APPLICATION_JSON_VALUE,   produces = { MediaType.APPLICATION_JSON_VALUE })
	public @ResponseBody String addAdmin(@RequestBody Admin admin) {
		
		
		return adservice.createAdmin(admin);
	}
	 
	// function returning list of admin
	@PostMapping(value = "/getallAdmin")
	public List<Admin> getAdminData() {
		return adservice.getAllAdmin();

	}

}
