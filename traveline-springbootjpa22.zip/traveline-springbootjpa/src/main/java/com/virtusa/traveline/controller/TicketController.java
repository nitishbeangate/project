package com.virtusa.traveline.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.virtusa.traveline.model.Admin;
import com.virtusa.traveline.model.PassengerContact;
import com.virtusa.traveline.model.PassengerDetail;
import com.virtusa.traveline.service.TicketService;

@RestController
@RequestMapping("/generate")
public class TicketController {
	@Autowired
	TicketService ticketservice;

	@PostMapping(value="/ticket",consumes = MediaType.APPLICATION_JSON_VALUE,   produces = { MediaType.APPLICATION_JSON_VALUE })
	public @ResponseBody String generateTicket(@RequestBody PassengerContact passengercontact,List<PassengerDetail> passengerdetail) {
		
		
		return ticketservice.ticketGeneration(passengercontact,passengerdetail);
	}
}
