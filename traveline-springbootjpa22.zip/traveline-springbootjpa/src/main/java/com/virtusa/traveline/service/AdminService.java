package com.virtusa.traveline.service;

import java.util.List;

import com.virtusa.traveline.model.Admin;
//import com.virtusa.traveline.repository.AdminRepository.AdminData;


public interface AdminService {

	//function to create new admin
	public String createAdmin(Admin admin);
	
	//function to fetch all admin
	
   public List<Admin> getAllAdmin();
}
