package com.virtusa.busbooking.dao.interfaces;

import java.sql.SQLException;
import java.util.List;

import com.virtusa.busbooking.models.getCity;

public interface cityDao {
public List<getCity> getCityName() throws SQLException;
}
