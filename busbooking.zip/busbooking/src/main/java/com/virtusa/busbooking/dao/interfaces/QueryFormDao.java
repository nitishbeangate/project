package com.virtusa.busbooking.dao.interfaces;

import java.sql.SQLException;
import java.util.List;

import com.virtusa.busbooking.models.QueryForm;

public interface QueryFormDao {
	   
    public boolean addQuery(QueryForm query) throws SQLException;
    public List<QueryForm> getQuery() throws SQLException;
}