package com.virtusa.busbooking.models;

public class getCity {
private String city;

public String getCity() {
	return city;
}

public void setCity(String city) {
	this.city = city;
}

}
