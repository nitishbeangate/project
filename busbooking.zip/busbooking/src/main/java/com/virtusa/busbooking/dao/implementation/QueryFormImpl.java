package com.virtusa.busbooking.dao.implementation;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import com.virtusa.busbooking.dao.interfaces.QueryFormDao;
import com.virtusa.busbooking.helpers.MySQlHelper;
import com.virtusa.busbooking.models.QueryForm;

public class QueryFormImpl implements QueryFormDao {
    private Connection conn;
    private CallableStatement callable;
    private Statement statement;
    private PreparedStatement pre;
    private ResultSet rs;
    QueryForm queryform;
    private List<QueryForm> queryformlist;
    
    public boolean addQuery(QueryForm query) throws SQLException {
        // TODO Auto-generated method stub
        conn=MySQlHelper.getConnection();
        int count=0;
        boolean status=false;
        ResourceBundle rb = ResourceBundle.getBundle("com/virtusa/busbooking/resources/db");
        try {
            callable=conn.prepareCall("call addQueryform(?,?)");
            
            callable.setString(1, query.getEmail());
            callable.setString(2, query.getQuerymessage());
            
            count=callable.executeUpdate();
            if(count>0)
                status=true;
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            //e.printStackTrace();
        }
        finally {
            conn.close();
        }
        
        
        
        return status;
    }

 

    public List<QueryForm> getQuery() throws SQLException {
        // TODO Auto-generated method stub
        conn=MySQlHelper.getConnection();
        queryformlist=new ArrayList<QueryForm>();
        ResourceBundle rb = ResourceBundle.getBundle("com/virtusa/busbooking/resources/db");
        String query=rb.getString("getQuery");   
        try {
            statement=conn.createStatement();
            rs=statement.executeQuery(query);
            while(rs.next())
            {
                queryform= new QueryForm();
                queryform.setId(rs.getInt(1));
                queryform.setEmail(rs.getString(2));
                queryform.setQuerymessage(rs.getString(3));
                queryform.setDate(rs.getDate(4));
                queryformlist.add(queryform);
            }
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        finally
        {
            conn.close();
        }
        
        return queryformlist;
    }
    
    
    

 

    
    
    

 

}
