package com.virtusa.busbooking.dao.interfaces;
import com.virtusa.busbooking.models.*;
import java.sql.SQLException;
import java.util.List;

public interface AdminDao {
Boolean AdminLogin(AdminLogin adminlogin) throws SQLException;
int addAdmin(AddAdmin addAdmin) throws SQLException;
public List<AdminList> GetAdminDetail() throws SQLException;
}
