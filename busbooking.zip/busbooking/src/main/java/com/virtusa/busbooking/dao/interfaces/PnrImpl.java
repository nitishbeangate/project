package com.virtusa.busbooking.dao.interfaces;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import com.virtusa.busbooking.helpers.MySQlHelper;
import com.virtusa.busbooking.models.Pnr;

 

public class PnrImpl implements PnrDao {

 

    private Connection conn;
    private ResultSet resultSet;
    private PreparedStatement pre;
    private ResourceBundle rb;
    private Pnr p;
    @Override
    public Pnr getDetails(String pnrNo) throws SQLException {
        // TODO Auto-generated method stub
        rb=ResourceBundle.getBundle("com/virtusa/busbooking/resources/db");
        conn=MySQlHelper.getConnection();
        String query=rb.getString("getDetails");
        p=new Pnr();
      try
    {
            
            
            pre=conn.prepareStatement(query);
            pre.setString(1,pnrNo);
            resultSet=pre.executeQuery();// executes the query
            System.out.println("query executed");
            resultSet.next();
            p.setJourneyDate(resultSet.getDate("journey_date"));
            p.setLocTo(resultSet.getString("loc_to"));
            p.setLocFrom(resultSet.getString("loc_from"));
            p.setTotalSeats(resultSet.getInt("total_seats"));
        
        }
        catch(SQLException e)
        {
            //e.printStackTrace();
        }
        finally
        {
            conn.close();
        }
        
        return p;
            
    }
}