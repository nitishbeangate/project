package com.virtusa.busbooking.models;

public class AdminList {

private int aid;

private String aname;

private String aemail;
private String creationDate;



public String getCreationDate() {
	return creationDate;
}

public void setCreationDate(String creationDate) {
	this.creationDate = creationDate;
}

public String getAname() {

	return aname;

}

public int getAid() {

	return aid;

}

public void setAid(int aid) {

	this.aid = aid;

}

public void setAname(String aname) {

	this.aname = aname;

}

public String getAemail() {

	return aemail;

}

public void setAemail(String aemail) {

	this.aemail = aemail;

}

}