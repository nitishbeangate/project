package com.virtusa.busbooking.models;

import java.util.List;

public class GenerateTicket {
private String MPname;
private String MPemail;
private String MPcontact;
private List<Passenger> passenger;
public String getMPname() {
	return MPname;
}
public void setMPname(String mPname) {
	MPname = mPname;
}
public String getMPemail() {
	return MPemail;
}
public void setMPemail(String mPemail) {
	MPemail = mPemail;
}
public String getMPcontact() {
	return MPcontact;
}
public void setMPcontact(String mPcontact) {
	MPcontact = mPcontact;
}
public List<Passenger> getPassenger() {
	return passenger;
}
public void setPassenger(List<Passenger> passenger) {
	this.passenger = passenger;
}



}
