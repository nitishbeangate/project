package com.virtusa.busbooking.dao.interfaces;

import java.sql.Date;
import java.sql.SQLException;
import java.util.List;

import com.virtusa.busbooking.models.SearchBus;

public interface SearchbusDao {
public List<SearchBus> search_Bus(String fromcity,String tocity,Date date) throws SQLException;
}
