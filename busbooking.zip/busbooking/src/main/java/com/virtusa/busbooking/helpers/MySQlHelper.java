package com.virtusa.busbooking.helpers;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ResourceBundle;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class MySQlHelper {
	private static Logger logger=Logger.getLogger(MySQlHelper.class);
	static
	{
		PropertyConfigurator.configure("log4j.properties");
	}
	public static Connection getConnection()
	{
		ResourceBundle rb=ResourceBundle.getBundle("com/virtusa/busbooking/resources/db");
		String UserName=rb.getString("user");
		String password=rb.getString("password");
		String url=rb.getString("url");
		String driverName=rb.getString("driver");
		Connection conn = null;
		
		try {
			Class.forName(driverName);
			conn=DriverManager.getConnection(url,UserName,password);
			logger.error("Class not found Exception");
			
		} catch(ClassNotFoundException e)
		{
			logger.error("Class not found Exception"+e.getMessage());
		}
		catch(SQLException e)
		{
			logger.error("SQL Exception"+e.getMessage());
		}
	     return conn;
	}
}
