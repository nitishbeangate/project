package com.virtusa.busbooking.dao.interfaces;

import java.sql.SQLException;




import com.virtusa.busbooking.models.Pnr;

 

public interface PnrDao {

 


    Pnr getDetails(String pnrNo) throws SQLException;

 

 

}