package com.virtusa.busbooking.dao.implementation;
import java.awt.Window.Type;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;

import com.virtusa.busbooking.dao.interfaces.*;
import com.virtusa.busbooking.helpers.MySQlHelper;
import com.virtusa.busbooking.models.AddBus;

public class AddBusImpl implements BusDao{

	private Connection conn;
	
	@Override
	public int addBus(AddBus addBus) throws SQLException
	{
		
		// TODO Auto-generated method stub
		
		int a=0,b=0,count=0,route_id=0;
		String bus_id=null;
		Connection conn=MySQlHelper.getConnection();
		try {
			
		   String strprocedure="{call addBus(?,?,?,?)}";
		   CallableStatement cs1= conn.prepareCall(strprocedure);
	       cs1.setString(1, addBus.getBusNo());
	       cs1.setString(2,addBus.getBusName());
	       cs1.setString(3,addBus.getBusType());
	       cs1.setInt(4,addBus.getTotalSeats());
	       a=cs1.executeUpdate();
	       System.out.println("a"+a);
	       bus_id=addBus.getBusNo();
	     
	       
	   if(a==1)
	   {
	       String strprocedure2="{call AddbusRoute(?,?,?,?,?)}";
			CallableStatement cs2= conn.prepareCall(strprocedure2);
			   cs2.setString(1, addBus.getLocFrom());
		       cs2.setString(2, addBus.getLocTo());
		       cs2.setInt(3, addBus.getDistance());
		       cs2.setInt(4, addBus.getFare());
		       cs2.registerOutParameter(5, Types.INTEGER);
		       b=cs2.executeUpdate();
		       System.out.println("b="+b);
		       route_id=cs2.getInt(5);
		      
	   }	
	   if(b==1)
	   {
		   
	   
       String strprocedure3="{call addBusSchedule(?,?,?,?)}";
		CallableStatement cs3= conn.prepareCall(strprocedure3);
		   cs3.setString(2, bus_id);
		   cs3.setInt(1, route_id);
		   cs3.setString(3, addBus.getArrivaltime());
		   cs3.setString(4, addBus.getDeparturetime());
	       count=cs3.executeUpdate();
	       System.out.println("count="+count);
	      
	   }
	       
	}
		catch(SQLException e) 
		{
			
			System.out.println(e.getMessage());
		}
		finally 
		{
			conn.close();
		}
		
		return count;
	}

	@Override
	public int updateBus(AddBus updatebus) throws SQLException
	{
		
	        // TODO Auto-generated method stub
	        Connection conn=MySQlHelper.getConnection();
	        int result1=0;
	      try {
	                    //update bus details
	                
	                    String strProcedure4="{call updateBusDetails(?,?,?,?)}";
	                    CallableStatement cs4 = conn.prepareCall(strProcedure4);
	                    cs4.setString(1, updatebus.getBusNo());
	                    System.out.println("ssss"+updatebus.getBusNo());
	                   cs4.setString(2,updatebus.getBusName());
	                   System.out.println("ssss"+updatebus.getBusName());
	                   cs4.setString(3,updatebus.getBusType());
	                   System.out.println("ssss"+updatebus.getBusType());
	                   cs4.setInt(4,updatebus.getTotalSeats());
	               
	                    result1=cs4.executeUpdate();
	                
	                    
	      }
	                    catch(SQLException e) 
	            		{
	            			
	            			System.out.println(e.getMessage());
	            		}
	            		finally 
	            		{
	            			conn.close();
	            		}
	            		
	            		return result1;
	            	
	                   
	}

	
}

