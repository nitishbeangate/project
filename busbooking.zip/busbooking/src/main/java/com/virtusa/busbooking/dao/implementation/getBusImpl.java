package com.virtusa.busbooking.dao.implementation;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import com.virtusa.busbooking.dao.interfaces.getBusDao;
import com.virtusa.busbooking.helpers.MySQlHelper;
import com.virtusa.busbooking.models.GetBus;



public class getBusImpl implements getBusDao 
{
	private Connection conn;
	private Statement statement;
	private ResultSet resultSet;
	private ResourceBundle rb;
	private List<GetBus> getBusList;
	private GetBus getbus;

	@Override
	public List<GetBus> getBusList() throws SQLException {
		// TODO Auto-generated method stub
		conn=MySQlHelper.getConnection();
		 rb=ResourceBundle.getBundle("com/virtusa/busbooking/resources/db");
		String query=rb.getString("getBus");
		
		getBusList = new ArrayList<GetBus>();
		try {
			statement=conn.createStatement();
			resultSet=statement.executeQuery(query);
			
			while(resultSet.next())
			{
				
				getbus=new GetBus();
				
				getbus.setBus_no(resultSet.getString(1));
				//System.out.println("busno="+resultSet.getString(1));
				getbus.setBus_name(resultSet.getString(2));
				//System.out.println("busno="+resultSet.getString(2));
				getbus.setBus_type(resultSet.getString(3));
				//System.out.println("busno="+resultSet.getString(3));
				getbus.setTotalSeats(resultSet.getInt(4));
				getbus.setLocFrom(resultSet.getString(5));
				getbus.setLocTo(resultSet.getString(6));
				System.out.println("busno="+resultSet.getString(6));
				
				getbus.setDistance(resultSet.getInt(7));
				getbus.setFare(resultSet.getInt(8));
				getbus.setArrivaltime(resultSet.getString(9));
				getbus.setDeparturetime(resultSet.getString(10));
				getBusList.add(getbus);
				
			}
			
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		finally {
			conn.close();
			
		}
		return getBusList;
		
	}

}
