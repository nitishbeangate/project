package com.virtusa.busbooking.dao.interfaces;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import com.virtusa.busbooking.helpers.MySQlHelper;
import com.virtusa.busbooking.models.Feedback;

public class FeedbackImpl implements FeedbackDao {

private Connection conn;
   private CallableStatement callable;
   private Statement statement;
   private ResultSet resultSet;
   private ResourceBundle rb;
   private List<Feedback> feedbackList;
   private Feedback feedback;
   
   
@Override
public int addFeedback(Feedback feedback) throws SQLException {
// TODO Auto-generated method stub
conn=MySQlHelper.getConnection();
int count=0;
try {
callable= conn.prepareCall("{call addFeedback(?,?,?)}");
//System.out.println(feedback.getPassengername());

callable.setString(1,feedback.getPassengername());
callable.setString(2, feedback.getPassengeremail());
callable.setString(3,feedback.getComment());
count=callable.executeUpdate();
//conn.commit();
}
catch(SQLException e)
{
//e.printStackTrace();

}
finally {
conn.close();
}

return count;
}

@Override
public List<Feedback> getFeedback() throws SQLException {
// TODO Auto-generated method stub
	conn=MySQlHelper.getConnection();
    rb=ResourceBundle.getBundle("com/virtusa/busbooking/resources/db");
    feedbackList=new ArrayList<Feedback>();
    String query=rb.getString("getFeedback");
    try {
        statement=conn.createStatement();
        resultSet=statement.executeQuery(query);
        while(resultSet.next())
        {
            feedback=new Feedback();
            feedback.setFeedback_id(resultSet.getInt(1));
            feedback.setPassengername(resultSet.getString(2));
        //    System.out.println(feedback.getPassengername());
               
                  feedback.setPassengeremail(resultSet.getString(3));
                  feedback.setComment(resultSet.getString(4));
                  feedbackList.add(feedback);
                
        }
                   
    }catch(SQLException e) {
        System.out.println(e.getMessage());
    }
    finally
    {
        conn.close();
    }
    return feedbackList;
}
}