package com.virtusa.busbooking.models;

import java.sql.Date;

public class QueryForm {
	   
    private String email;
    private String querymessage;
    private int id;
    private Date date;
   
   
    public Date getDate() {
        return date;
    }
    public void setDate(Date date) {
        this.date = date;
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public String getQuerymessage() {
        return querymessage;
    }
    public void setQuerymessage(String querymessage) {
        this.querymessage = querymessage;
    }
   
   
   
}
