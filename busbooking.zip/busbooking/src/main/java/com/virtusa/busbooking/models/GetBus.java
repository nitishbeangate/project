package com.virtusa.busbooking.models;

public class GetBus {
	private String bus_no;
	private int totalSeats;
	private String bus_name;
	private String bus_type;
	private String locFrom;
	private String locTo;
	private int distance;
	private int fare;
	private String arrivaltime;
	private String departuretime;
	public String getBus_no() {
		return bus_no;
	}
	public void setBus_no(String bus_no) {
		this.bus_no = bus_no;
	}
	public int getTotalSeats() {
		return totalSeats;
	}
	public void setTotalSeats(int totalSeats) {
		this.totalSeats = totalSeats;
	}
	public String getBus_name() {
		return bus_name;
	}
	public void setBus_name(String bus_name) {
		this.bus_name = bus_name;
	}
	public String getBus_type() {
		return bus_type;
	}
	public void setBus_type(String bus_type) {
		this.bus_type = bus_type;
	}
	public String getLocFrom() {
		return locFrom;
	}
	public void setLocFrom(String locFrom) {
		this.locFrom = locFrom;
	}
	public String getLocTo() {
		return locTo;
	}
	public void setLocTo(String locTo) {
		this.locTo = locTo;
	}
	public int getDistance() {
		return distance;
	}
	public void setDistance(int distance) {
		this.distance = distance;
	}
	public int getFare() {
		return fare;
	}
	public void setFare(int fare) {
		this.fare = fare;
	}
	public String getArrivaltime() {
		return arrivaltime;
	}
	public void setArrivaltime(String arrivaltime) {
		this.arrivaltime = arrivaltime;
	}
	public String getDeparturetime() {
		return departuretime;
	}
	public void setDeparturetime(String departuretime) {
		this.departuretime = departuretime;
	}
	
}
