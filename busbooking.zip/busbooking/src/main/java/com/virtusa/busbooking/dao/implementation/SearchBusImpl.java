package com.virtusa.busbooking.dao.implementation;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import com.virtusa.busbooking.dao.interfaces.SearchbusDao;
import com.virtusa.busbooking.helpers.MySQlHelper;
import com.virtusa.busbooking.models.SearchBus;

public class SearchBusImpl implements SearchbusDao {
private Connection conn;  //connection
private PreparedStatement ps; //toexecute query
private ResultSet rs; //resultset 
private List<SearchBus> availableBus; //store bus detail as object
private SearchBus sb;
	@Override
	public List<SearchBus> search_Bus(String fromcity, String tocity, Date date) throws SQLException {
		// TODO Auto-generated method stub
		//catching exception
		try 
		{
			availableBus=new ArrayList<SearchBus>(); //creating array list
			conn=MySQlHelper.getConnection(); //getting connection
			ResourceBundle rb=ResourceBundle.getBundle("com/virtusa/busbooking/resources/db");
			String searchBusQuery=rb.getString("searchbusquery"); //fetching query
			ps=conn.prepareStatement(searchBusQuery); //passing query
			ps.setString(1, fromcity); //setting parameter
			ps.setString(2, tocity);
			ps.setDate(3, date);
			rs=ps.executeQuery(); //executing query and storing in resultset
			while(rs.next())   //loop to fetch all row value from database
			{
		    sb=new SearchBus(); //creating object of pojo class
		    sb.setBus_no(rs.getString(1)); //receiving column value and setting to pojo class
		    sb.setBus_name(rs.getString(2));
		    sb.setLocFrom(rs.getString(3));
		    sb.setLocTo(rs.getString(4));
		    sb.setBus_type(rs.getString(5));
		    sb.setArrivaltime(rs.getString(6));
		    sb.setDeparturetime(rs.getString(7));
		    sb.setDistance(rs.getInt(7));
		    sb.setAvailableSeat(rs.getInt(8));
		    availableBus.add(sb); //adding to list
			}
			
		}
		catch (SQLException e) {
			// TODO: handle exception
			
		}
		finally {
			//closing connection
			conn.close();
		}
		//returning list
		return availableBus;
	}

}
