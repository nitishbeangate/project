package com.virtusa.busbooking.dao.implementation;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import com.virtusa.busbooking.dao.interfaces.cityDao;
import com.virtusa.busbooking.helpers.MySQlHelper;
import com.virtusa.busbooking.models.getCity;

public class CityImpl implements cityDao {
private Connection conn;
private List<getCity> citylistname;
private Statement statement;
private ResultSet resultset;
private getCity getcity;
	@Override
	public List<getCity> getCityName() throws SQLException {
		// TODO Auto-generated method stub
		conn=MySQlHelper.getConnection();
		ResourceBundle rb = ResourceBundle.getBundle("com/virtusa/busbooking/resources/db");
		citylistname=new ArrayList<getCity>();
		 String query=rb.getString("getCityName");
		try {
			statement=conn.createStatement();
			resultset=statement.executeQuery(query);
			while(resultset.next())
			{
			getcity=new getCity();
			getcity.setCity(resultset.getString(1));
			citylistname.add(getcity);
			}
		} catch (SQLException e) {
			// TODO: handle exception
		}
		finally {
		conn.close();	
		}
		return citylistname;
	}

	
}
