package com.virtusa.busbooking.dao.implementation;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import com.virtusa.busbooking.dao.interfaces.PassengerDao;
import com.virtusa.busbooking.helpers.MySQlHelper;
import com.virtusa.busbooking.models.Passenger;

public class PassengerImpl implements PassengerDao {
private ResourceBundle rb;
private PreparedStatement ps;
private ResultSet rs;
private Connection conn;
private List<Passenger> plist;
	@Override
	public List<Passenger> GetPassengerDetail(String psgid) throws SQLException {
		// TODO Auto-generated method stub
	rb=ResourceBundle.getBundle("com/virtusa/busbooking/resources/db");
	String Passengerdetail=rb.getString("PassengerDetails");
	conn=MySQlHelper.getConnection();
	plist=new ArrayList<Passenger>();
	Passenger p=null;
     try {
    	 ps=conn.prepareStatement(Passengerdetail);
    		ps.setInt(1, Integer.parseInt(psgid));
    		rs=ps.executeQuery();
    		while(rs.next())
    		{
    			p=new Passenger();
    			p.setPname(rs.getString(1));
    			p.setAge(rs.getString(2));
    			p.setGender(rs.getString(3));
    			p.setSeatNO(rs.getString(4));
    			plist.add(p);
    		}
	} catch (SQLException e) {
		// TODO: handle exception
		
	}
     finally {
		conn.close();
	}
		return plist;
	}

}
