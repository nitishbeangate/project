package com.virtusa.busbooking.dao.implementation;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Types;
import java.util.List;


import com.virtusa.busbooking.dao.interfaces.GenerateTicketDao;
import com.virtusa.busbooking.helpers.MySQlHelper;
import com.virtusa.busbooking.models.GenerateTicket;
import com.virtusa.busbooking.models.Passenger;

public class GenerateTicketImpl implements GenerateTicketDao {

	private Connection conn;
	private CallableStatement callable;
	
	@Override
	public boolean addPassenger(GenerateTicket ticket) throws SQLException {
		// TODO Auto-generated method stub
		int passengerId=0;
		conn=MySQlHelper.getConnection();
       try {
    	  callable= conn.prepareCall("{call addPassengerContact(?,?,?,?)}");
    	  callable.setString(1, ticket.getMPname());
    	  callable.setString(2, ticket.getMPemail());
    	  callable.setString(3, ticket.getMPcontact());
    	  callable.registerOutParameter(4, Types.INTEGER);
    	  callable.executeUpdate();
    	  passengerId=callable.getInt(4);
    	  System.out.println(passengerId);
    	  if (passengerId!=0) {
    		  System.out.println(passengerId);
    		  for(Passenger passenger:ticket.getPassenger()) {
    			  System.out.println(passenger.getGender());
    			  callable= conn.prepareCall("{call passengerDetail(?,?,?,?,?)}");
    			  callable.setInt(1,passengerId);
    			  callable.setString(2,passenger.getPname());
    			  callable.setInt(3,Integer.parseInt(passenger.getAge()));
    			  callable.setString(4,passenger.getGender());
    			  callable.setInt(5,Integer.parseInt(passenger.getSeatNO()));
    			  callable.executeUpdate();
    		  }
		}
    	 
       }
       catch(SQLException e)
       {
    	   System.out.println(e.getMessage());
       }
       finally
       {
    	   conn.close();
       }
	return true;
       
		/*ticket.getMPcontact();
		List<Passenger> passengerList=ticket.getPassenger();
		for(Passenger passenger:passengerList){
			
		}
		return false;*/
	}


	@Override
	public GenerateTicket getTicket(String pnrNo) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

}
