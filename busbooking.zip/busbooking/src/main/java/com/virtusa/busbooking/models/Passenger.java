package com.virtusa.busbooking.models;

public class Passenger {
	private String seatNO;
	private String pname;
	private String age;
	private String gender;
	
	public String getSeatNO() {
		return seatNO;
	}
	public void setSeatNO(String seatNO) {
		this.seatNO = seatNO;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	
}
