package com.virtusa.busbooking.models;
public class Feedback {
private int feedback_id;
private String passengername;
private String passengeremail;
private String comment;
public String getPassengername() {
return passengername;
}
public void setPassengername(String passengername) {
this.passengername = passengername;
}
public String getPassengeremail() {
return passengeremail;
}
public void setPassengeremail(String passengeremail) {
this.passengeremail = passengeremail;
}
public String getComment() {
return comment;
}
public void setComment(String comment) {
this.comment = comment;
}
public int getFeedback_id() { 
	return feedback_id;
} 
public void setFeedback_id(int feedback_id) { 
    	this.feedback_id = feedback_id; 
}
     

 


}