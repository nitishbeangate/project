package com.virtusa.busbooking.models;
public class AddBus {
private String busNo;
private String busName;
private String busType;
private int totalSeats;
private String locFrom;
public String getLocFrom() {
	return locFrom;
}
public void setLocFrom(String locFrom) {
	this.locFrom = locFrom;
}
public String getLocTo() {
	return locTo;
}
public void setLocTo(String locTo) {
	this.locTo = locTo;
}
public int getDistance() {
	return distance;
}
public void setDistance(int distance) {
	this.distance = distance;
}
public int getFare() {
	return fare;
}
public void setFare(int fare) {
	this.fare = fare;
}
private String locTo;
private int distance;
private int fare;
public String getBusNo() {
return busNo;
}
public void setBusNo(String busNo) {
this.busNo = busNo;
System.out.println(this.busNo);
}
public String getBusName() {
return busName;
}
public void setBusName(String busName) {
this.busName = busName;
System.out.println(this.busName);
}
public String getBusType() {
return busType;
}
public void setBusType(String busType) {
this.busType = busType;
System.out.println(this.busType);
}
public int getTotalSeats() {
return totalSeats;
}
public void setTotalSeats(int totalSeats) {
this.totalSeats = totalSeats;
System.out.println(this.totalSeats);
}

private String arrivaltime;
private String departuretime;
public String getArrivaltime() {
	return arrivaltime;
}
public void setArrivaltime(String arrivaltime) {
	this.arrivaltime = arrivaltime;
}
public String getDeparturetime() {
	return departuretime;
}
public void setDeparturetime(String departuretime) {
	this.departuretime = departuretime;
}

}
