package com.virtusa.busbooking.models;

public class AddAdmin {
	String adusername;
	String ademail;
	String adpassword;
	public String getAdusername() {
		return adusername;
	}
	public void setAdusername(String adusername) {
		this.adusername = adusername;
	}
	public String getAdemail() {
		return ademail;
	}
	public void setAdemail(String ademail) {
		this.ademail = ademail;
	}
	public String getAdpassword() {
		return adpassword;
	}
	public void setAdpassword(String adpassword) {
		this.adpassword = adpassword;
	}
	
}
