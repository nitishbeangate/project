package com.virtusa.busbooking.dao.interfaces;

import java.sql.SQLException;

import com.virtusa.busbooking.models.AddBus;

public interface BusDao {

int  addBus(AddBus addBus) throws SQLException;


int updateBus(AddBus updatebus) throws SQLException;



}
