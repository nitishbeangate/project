package com.virtusa.busbooking.dao.interfaces;

import java.sql.SQLException;
import java.util.List;
import com.virtusa.busbooking.models.Feedback;


public interface FeedbackDao {

int addFeedback(Feedback feedback) throws SQLException;
List<Feedback> getFeedback() throws SQLException;

}