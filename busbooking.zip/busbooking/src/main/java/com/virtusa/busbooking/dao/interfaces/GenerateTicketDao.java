package com.virtusa.busbooking.dao.interfaces;

import java.sql.SQLException;

import com.virtusa.busbooking.models.GenerateTicket;

public interface GenerateTicketDao {
	boolean addPassenger(GenerateTicket ticket) throws SQLException;
	GenerateTicket getTicket(String pnrNo) throws SQLException;
}
