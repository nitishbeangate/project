package com.virtusa.busbooking.dao.interfaces;

import java.sql.SQLException;
import java.util.List;

import com.virtusa.busbooking.models.Passenger;

public interface PassengerDao {
public List<Passenger> GetPassengerDetail(String psgid) throws SQLException;
}
