package com.virtusa.busbooking.dao.implementation;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import com.virtusa.busbooking.dao.interfaces.AdminDao;
import com.virtusa.busbooking.helpers.MySQlHelper;
import com.virtusa.busbooking.models.AddAdmin;
import com.virtusa.busbooking.models.AdminList;
import com.virtusa.busbooking.models.AdminLogin;

public class Adminimpl implements AdminDao {
private Connection conn;
private List<AdminList> Adminlist;
private Statement statement;
private ResultSet rs;
	@Override
	public Boolean AdminLogin(AdminLogin adminlogin) throws SQLException {
		// TODO Auto-generated method stub
		conn=MySQlHelper.getConnection();
		int status=0;
		Boolean loc=false;
		try
		{
		CallableStatement cs=conn.prepareCall("{call checkAdmin(?,?,?)}"); //procedure call
		cs.setString(1, adminlogin.getAdemail()); //getting value from pojo class
		cs.setString(2, adminlogin.getAdpassword());
		cs.registerOutParameter(3, Types.INTEGER);
		cs.execute(); //executing procedure
		 status=cs.getInt(3);
		 if (status==1) {
			loc=true;
		}
		}
		catch (SQLException e) {
			// TODO: handle exception
		}
		finally {
			conn.close();
		}
		return loc;
	}
 public int addAdmin(AddAdmin addadmin) throws SQLException
 {
	 int count=0;
	 conn=MySQlHelper.getConnection();
	
  try {
	  CallableStatement cd=conn.prepareCall("{call addAdmin(?,?,?)}");
	  cd.setString(1, addadmin.getAdusername());
	  cd.setString(2, addadmin.getAdemail());
	  cd.setString(3, addadmin.getAdpassword());
	 int a= cd.executeUpdate();
	 System.out.println(a);
} 
  catch (SQLException e) {
	// TODO: handle exception
	  System.out.print( e.getMessage());
}
  finally {
	// TODO: handle finally clause
	  conn.close();
}	
  return count;
 }
 public List<AdminList> GetAdminDetail() throws SQLException {

		AdminList adlist;

 conn=MySQlHelper.getConnection(); //receiving connection

 Adminlist=new ArrayList<AdminList>(); //list that store admin details

  //    loading resource bundle

 ResourceBundle rb=ResourceBundle.getBundle("com/virtusa/busbooking/resources/db");

 String selectquery=rb.getString("AdminDetail");

 statement=conn.createStatement();

 rs=statement.executeQuery(selectquery);

 try

 {

 while(rs.next())	

 {

 	adlist=new AdminList();

 	adlist.setAid(rs.getInt(1));

 	adlist.setAname(rs.getString(2));

 	adlist.setAemail(rs.getString(3));
 	adlist.setCreationDate(rs.getString(4));

 	Adminlist.add(adlist);

 }

 }

 catch(SQLException e)

 {

 	

 	e.printStackTrace();

 }

 finally {

		conn.close();

	}

		return Adminlist;

	}
}
