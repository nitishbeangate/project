	$(document).ready(function(){
		generatesit();
		var bookedsit=[1,5,7,9,12];
		function generatesit()
		{
			for (var i=1;i<=50;i++) {
	   var a="<button type='button'data-seat='"+i+"' class='btn seat'>"+i+"</button> ";
	    	var b="<button type='button' class='btn btn-danger'>"+i+"</button> ";

	    if (i<=25) {

	    $(".seatdesign").append(a);
	    continue;
	    }
	    $(".seatdesign1").append(a);
	}
	    }
    $(".seat").click(function(){
    var seatno=$(this).data('seat');
    $("#psgdetail").removeClass("hidden");
    if ($(this).hasClass("btn-success")) {
    	$('button[data-seat = '+seatno+']').removeClass("btn-success");
    	 $("#s"+seatno).remove();	
	}
    else
    	{
    	 $('button[data-seat = '+seatno+']').toggleClass('btn-success');
    	 appendpassenger(seatno);
    	}
   
    });
    function appendpassenger(seat)
    {
    	var appendrow="";
    	appendrow+="<div class='panel panel-default' id='s"+seat+"'><div class='panel-body'>";
    	appendrow+="<div class='col-md-2 col-xs-12'>";
    	appendrow+="<input type='text' class='form from-control' value='"+seat+"' readonly></div>";
    	appendrow+="<div class='col-md-4 col-xs-12'>";
		appendrow+="<input type='text' name='' placeholder='Enter Name' class='form form-control'></div>";
		appendrow+="<div class='col-md-3 col-xs-12'>";
		appendrow+="<input type='number' name='' placeholder='Enter age'class='form form-control'></div>";
		appendrow+="<div class='col-md-3'>";
		appendrow+="<select class='form form-control'>";
		appendrow+="<option value=''>Select</option><option>Male</option><option>Female</option>";
		appendrow+="</select>";
		appendrow+="</div></div></div>";
		$("#appendpassenger").append(appendrow);
    }
    $("nexttopayment").click(function(){
    	var seatno=[];
    	var
    });
	});