package com.virtusa.traveline.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.virtusa.traveline.model.PassengerPayment;

public interface PaymentRepository extends JpaRepository<PassengerPayment, Integer> {

}
