//jquery start
$(document).ready(function(){
	
	//function calling
	generatesit();

	//function to generate seat
	function generatesit()
	{
		//looping
		for (var i=1;i<=50;i++) {
			var a="<button type='button'data-seat='"+i+"' class='btn seat'>"+i+"</button> ";
			var b="<button type='button' class='btn btn-danger'>"+i+"</button> ";
        //condition
			if (i<=25) {

				$(".seatdesign").append(a);
				continue;
			}
			$(".seatdesign1").append(a);
		}
	}
	//on seat click receiving seat no and adding class 
	$(".seat").click(function(){
		var seatno=$(this).data('seat');
		$("#psgdetail").removeClass("hidden");
		if ($(this).hasClass("btn-success")) {
			$('button[data-seat = '+seatno+']').removeClass("btn-success");
			$("#s"+seatno).remove();	
		}
		else
		{
			$('button[data-seat = '+seatno+']').toggleClass('btn-success');
			appendpassenger(seatno);
		}

	});
	//function to generate passenger details
	function appendpassenger(seat)
	{
		//concatenation
		var appendrow="";
		appendrow+="<div class='panel panel-default' id='s"+seat+"'><div class='panel-body'>";
		appendrow+="<div class='col-md-2 col-xs-12'>";
		appendrow+="<input type='text' class='form from-control seat_no' name='seat_no' value='"+seat+"' readonly></div>";
		appendrow+="<div class='col-md-4 col-xs-12'>";
		appendrow+="<input type='text' name='pname' placeholder='Enter Name' class='form form-control pname'></div>";
		appendrow+="<div class='col-md-3 col-xs-12'>";
		appendrow+="<input type='number' name='p_age' placeholder='Enter age' class='form form-control p_age'></div>";
		appendrow+="<div class='col-md-3'>";
		appendrow+="<select class='form form-control pgender' name='pgender'>";
		appendrow+="<option value=''>Select</option><option value='male'>Male</option><option value='female'>Female</option>";
		appendrow+="</select>";
		appendrow+="</div></div></div>";
		//appending form
		$("#appendpassenger").append(appendrow);
	}
	//goto payment
	$("#nexttopayment").click(function(){
		//checking null validation
		if($("#Pcname").val()=="" || $("#pemail").val()=="" || $("#Pcontact").val()=="")
			{
			$("#pcontacterror").show().hide(6000);
			return;
			}
		//email validation
		else if(!validateEmail($("#pemail").val()))
	    {
		$("#pcontacterror").show().html("please enter valid email").hide(10000);
	    }
		//phone validation
	else if(($("#Pcontact").val()).length<10)
	    {
		$("#pcontacterror").show().html("Mobile Number must be 10 digit").hide(10000);
	    }
		//all validation done then
		else
			{
		$("#passengerDetail").hide();
		$("#paymentDiv").show();
		$("#paymentpage").html("Payment");
			}
	});
	//goback to passenger
	$("#backtopasseger").click(function(){
		$("#passengerDetail").show();
		$("#paymentDiv").hide();
		$("#paymentpage").html("Available Seat");
	});
	//email validation function
	//email validation
	function validateEmail($email) {

	      var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;

	 

	      return emailReg.test( $email );

	 

	    }
	
	
	
	//click function 
	$("#paymentDone").click(function(){
        //array declaration
		 var jsonObj = [];
		  var passenger={"passengerData":[]};

				  $('.seat_no').each(function(index)
				  {
				    passenger.passengerData.push({
				      "seatNo": $('.seat_no').val(), 
				      "pname":$('.pname').val(), 
				      "age":parseInt($('.p_age').val()),
				      "gender":$('.pgender').val()
				    });
				  });
       //for each loop
		/*$(".seat_no").each(function() {

	        var seatno = $(".seat_no").val();
	        var pname = $(".pname").val();

	        passenger = {}
	        passenger ["seatNo"] =seatno;
	        passenger ["pname"] = pname;

	        jsonObj.push(passenger);
		});*/
		/*$('.seat_no').each(function(){
			seat_no.push($(this).val());
                  
		});*/

	/*	$('.pname').each(function(){
			pname.push($(this).val());
		});

		$('.pgender option:selected').each(function(){
			pgender.push($(this).text());
		});
		//fetching all age using class and pushing into array
		$('.p_age').each(function(){
			p_age.push($(this).val());
		});*/
				 
		//sending all data to jsp pages
		/*var passenger={};
		passenger["seatNo"]=seat_no;
		passenger["pname"]=pname;*/
		var passengerData=JSON.stringify(passenger);
		alert(passengerData);
		//converting form to array object
		var contactData={"contactData":JSON.stringify($('#pContact').serializeJSON())};
		
		var paymentData={"paymentData":JSON.stringify($('#paymentDetail').serializeJSON())};
		jsonObj.push(contactData);
		jsonObj.push(paymentData);
		jsonObj.push(passenger);
		console.log(jsonObj);
		//alert(paymentData);
		//alert(contactData);
		$.ajax({
			method:'POST',
			contentType : "application/json",
			dataType:'json',
			url:'/generate/ticket',
			data:JSON.stringify(jsonObj), //converting form to single object
			success:function(data)
			{
				alert(data);	 
			},
			error:function(data)
			{
				alert(data);	 
			},
		});
	});
});