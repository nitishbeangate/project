package com.virtusa.traveline.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class PassengerPayment implements Serializable {

/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
@Id
@GeneratedValue(strategy = GenerationType.AUTO)

private int paymentId;
private int cardholdName;
private long cardnumber;
private int cvv;
private int amount;
private Date expiryDate;
public long getCardnumber() {
	return cardnumber;
}
public void setCardnumber(long cardnumber) {
	this.cardnumber = cardnumber;
}

public int getPaymentId() {
	return paymentId;
}
public void setPaymentId(int paymentId) {
	this.paymentId = paymentId;
}
public int getCardholdName() {
	return cardholdName;
}
public void setCardholdName(int cardholdName) {
	this.cardholdName = cardholdName;
}
public int getCvv() {
	return cvv;
}
public void setCvv(int cvv) {
	this.cvv = cvv;
}
public int getAmount() {
	return amount;
}
public void setAmount(int amount) {
	this.amount = amount;
}
public Date getExpiryDate() {
	return expiryDate;
}
public void setExpiryDate(Date expiryDate) {
	this.expiryDate = expiryDate;
}



	
}
